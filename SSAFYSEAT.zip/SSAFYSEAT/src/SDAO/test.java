package SDAO;

public class test {

	public static void main(String[] args) {
		SDAO dao = SDAO.getinstance();
		dao.shuffle();
	}

}
